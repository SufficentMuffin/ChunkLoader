package com.example.chunkloader.registry;

import com.example.chunkloader.block.ChunkLoaderBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModBlocks {

    private static final class_2960 ID = class_2960.method_60655("chunkloader", "chunk_loader");
    private static final class_5321<class_2248> BLOCK_KEY = class_5321.method_29179(class_7924.field_41254, ID);
    private static final class_5321<class_1792> ITEM_KEY = class_5321.method_29179(class_7924.field_41197, ID);

    public static final class_2248 CHUNK_LOADER = new ChunkLoaderBlock(
            class_4970.class_2251.method_9637()
                    .method_63500(BLOCK_KEY)
                    .method_31710(class_3620.field_16005)
                    .method_9629(3.0f, 6.0f)
                    .method_22488()
    );

    public static final class_1792 CHUNK_LOADER_ITEM = new class_1747(CHUNK_LOADER, new class_1792.class_1793().method_63686(ITEM_KEY).method_63685());

    public static void init() {
        class_2378.method_39197(class_7923.field_41175, BLOCK_KEY, CHUNK_LOADER);
        // No recipe file exists anywhere in data/ - only /give or creative can obtain this.
        class_2378.method_39197(class_7923.field_41178, ITEM_KEY, CHUNK_LOADER_ITEM);
    }
}
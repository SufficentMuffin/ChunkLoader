package com.example.chunkloader.registry;

import java.util.Set;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import com.example.chunkloader.block.ChunkLoaderBlockEntity;

public class ModBlockEntities {

    public static class_2591<ChunkLoaderBlockEntity> CHUNK_LOADER_BE;

    public static void init() {
        // Vanilla BlockEntityType.Builder's build() takes a DataFixerUpper
        // Type<?> argument, which mods almost always just pass null for
        // (that's what Fabric API's own wrapper did internally too). The
        // BlockEntityType$BlockEntityFactory nested interface this relies on
        // is private in these mappings - that's what
        // src/main/resources/chunkloader.accesswidener widens open, so no
        // Fabric API is needed for any of this.
        CHUNK_LOADER_BE = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655("chunkloader", "chunk_loader"),
                new class_2591<>(ChunkLoaderBlockEntity::new, Set.of(ModBlocks.CHUNK_LOADER))
        );
    }
}

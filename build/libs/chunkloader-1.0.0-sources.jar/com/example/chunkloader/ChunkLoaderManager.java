package com.example.chunkloader;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1923;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public final class ChunkLoaderManager {
    private static final Map<class_1923, Integer> ACTIVE_AREAS = new HashMap<>();

    private ChunkLoaderManager() {
    }

    public static int add(class_3218 world, int chunkX, int chunkZ, int radius, class_2168 source) {
        if (radius < 1) {
            source.method_9213(class_2561.method_43470("Chunk loader radius must be at least 1."));
            return 0;
        }

        class_1923 center = new class_1923(chunkX, chunkZ);
        int previousRadius = ACTIVE_AREAS.put(center, radius);
        if (previousRadius != 0) {
            removeArea(world, center, previousRadius);
        }

        applyArea(world, center, radius, true);
        source.method_9226(() -> class_2561.method_43470("Server chunk loader active at chunk (" + chunkX + ", " + chunkZ + ") radius " + radius + "."), true);
        return 1;
    }

    public static int remove(class_3218 world, int chunkX, int chunkZ, class_2168 source) {
        class_1923 center = new class_1923(chunkX, chunkZ);
        Integer radius = ACTIVE_AREAS.remove(center);
        if (radius == null) {
            source.method_9213(class_2561.method_43470("No active server chunk loader at chunk (" + chunkX + ", " + chunkZ + ")."));
            return 0;
        }

        removeArea(world, center, radius);
        source.method_9226(() -> class_2561.method_43470("Removed server chunk loader at chunk (" + chunkX + ", " + chunkZ + ")."), true);
        return 1;
    }

    private static void applyArea(class_3218 world, class_1923 center, int radius, boolean forced) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                world.method_17988(center.field_9181 + dx, center.field_9180 + dz, forced);
            }
        }
    }

    private static void removeArea(class_3218 world, class_1923 center, int radius) {
        applyArea(world, center, radius, false);
    }
}

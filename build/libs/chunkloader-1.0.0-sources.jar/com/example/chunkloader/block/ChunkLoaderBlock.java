package com.example.chunkloader.block;

import com.example.chunkloader.registry.ModBlockEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

/**
 * A block that force-loads chunks around itself and manually drives random
 * ticks in that area (vanilla forceload does NOT do this on its own -
 * random ticks normally require a real player nearby).
 *
 * NOTE: Minecraft's exact Block interaction method names/signatures have
 * shifted a couple of times across 1.21.x point releases (e.g.
 * onStateReplaced gained/changed its newState parameter). If this doesn't
 * compile as-is against 1.21.11+build.4, check net.minecraft.block.Block /
 * AbstractBlock in your local mapped sources for the current signature -
 * the logic inside each method body doesn't need to change, just the
 * method header.
 */
public class ChunkLoaderBlock extends class_2248 implements class_2343 {

    public ChunkLoaderBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ChunkLoaderBlockEntity(pos, state);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (!world.method_8608() && world instanceof class_3218 serverWorld
                && world.method_8321(pos) instanceof ChunkLoaderBlockEntity be) {
            be.applyForceLoad(serverWorld, true);
        }
    }

    // NOTE: as of 1.21.5+, onStateReplaced runs AFTER the block entity has
    // already been removed, and is passed the OLD state rather than the new
    // one - so it's no longer useful for per-instance cleanup here. The
    // actual "un-forceload on removal" logic lives in
    // ChunkLoaderBlockEntity#onBlockReplaced instead. This override is kept
    // only because AbstractBlock still requires/expects it to exist.
    @Override
    public void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        super.method_66388(state, world, pos, moved);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        return interact(state, world, pos, player);
    }

    @Override
    public class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.method_8608()) {
            player.method_7353(class_2561.method_43470("DEBUG: onUseWithItem was called!"), true);
        }
        return interact(state, world, pos, player);
    }

    private class_1269 interact(class_2680 state, class_1937 world, class_2338 pos, class_1657 player) {
        if (world.method_8321(pos) instanceof ChunkLoaderBlockEntity be) {
            if (!world.method_8608() && world instanceof class_3218 serverWorld) {
                if (player.method_7338()) {
                    be.cycleRadius(serverWorld);
                    player.method_7353(class_2561.method_43470("Chunk Loader radius set to " + be.getRadius()
                            + " chunk(s) (" + (be.getRadius() * 16) + " blocks)."), true);
                } else {
                    player.method_7353(class_2561.method_43470("Chunk Loader radius: " + be.getRadius()
                            + " chunk(s). Ask OP to change radiua."), true);
                }
            }
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.method_8608()) return null;
        return validateTicker(type, ModBlockEntities.CHUNK_LOADER_BE, ChunkLoaderBlockEntity::serverTick);
    }

    @SuppressWarnings("unchecked")
    protected static <T extends class_2586, E extends class_2586> class_5558<T> validateTicker(
            class_2591<T> givenType, class_2591<E> expectedType, class_5558<? super E> ticker) {
        return expectedType == givenType ? (class_5558<T>) ticker : null;
    }
}

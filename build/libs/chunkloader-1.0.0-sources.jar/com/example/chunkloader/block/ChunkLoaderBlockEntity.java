package com.example.chunkloader.block;

import com.example.chunkloader.registry.ModBlockEntities;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

public class ChunkLoaderBlockEntity extends class_2586 {

    // Preset radii (in chunks) the player cycles through with sneak + right-click.
    private static final int[] RADIUS_OPTIONS = {1, 2, 3, 4, 6, 8};

    // How many random-tick "rolls" to simulate per loaded chunk each cycle.
    // Vanilla's default random_tick_speed gamerule is 3 - this mirrors that.
    private static final int RANDOM_TICKS_PER_CHUNK = 3;

    // Run the simulation once per second (20 game ticks) instead of every
    // single tick, to keep this cheap even with a large radius.
    private static final int SIMULATION_INTERVAL_TICKS = 20;

    private int radiusIndex = 0;
    private int tickCounter = 0;

    public ChunkLoaderBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CHUNK_LOADER_BE, pos, state);
    }

    public int getRadius() {
        return RADIUS_OPTIONS[radiusIndex];
    }

    /** Un-forces the old radius, advances to the next preset, forces the new radius. */
    public void cycleRadius(class_3218 world) {
        applyForceLoad(world, false);
        radiusIndex = (radiusIndex + 1) % RADIUS_OPTIONS.length;
        applyForceLoad(world, true);
        method_5431();
    }

    /** Adds or removes forceload tickets for every chunk within the current radius. */
    public void applyForceLoad(class_3218 world, boolean forced) {
        class_1923 center = new class_1923(method_11016());
        int r = getRadius();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                world.method_17988(center.field_9181 + dx, center.field_9180 + dz, forced);
            }
        }
    }

    public static void serverTick(class_1937 world, class_2338 pos, class_2680 state, ChunkLoaderBlockEntity be) {
        if (!(world instanceof class_3218 serverWorld)) return;

        be.tickCounter++;
        if (be.tickCounter < SIMULATION_INTERVAL_TICKS) return;
        be.tickCounter = 0;

        be.simulateRandomTicks(serverWorld);
    }

    /**
     * Manually reproduces vanilla's random-tick behaviour: pick random block
     * positions inside each force-loaded chunk and call randomTick on them
     * if the block is one that reacts to random ticks (crops, cactus,
     * sugar cane, saplings, leaves, ice, etc).
     */
    private void simulateRandomTicks(class_3218 world) {
        class_1923 center = new class_1923(method_11016());
        int r = getRadius();
        class_5819 random = world.method_8409();

        int minY = world.method_31607();
        int height = world.method_31605();

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int chunkX = center.field_9181 + dx;
                int chunkZ = center.field_9180 + dz;

                if (!world.method_8393(chunkX, chunkZ)) continue;

                for (int i = 0; i < RANDOM_TICKS_PER_CHUNK; i++) {
                    int x = (chunkX << 4) + random.method_43048(16);
                    int z = (chunkZ << 4) + random.method_43048(16);
                    int y = minY + random.method_43048(height);
                    class_2338 randomPos = new class_2338(x, y, z);

                    class_2680 targetState = world.method_8320(randomPos);
                    if (targetState.method_26229()) {
                        targetState.method_26199(world, randomPos, random);
                    }
                }
            }
        }
    }

    /**
     * Called right before this block is actually replaced/removed - unlike
     * ChunkLoaderBlock#onStateReplaced (which now runs afterward, once the
     * block entity is already gone), this is the correct place to release
     * the forceload tickets while we can still reach world/pos cleanly.
     */
    @Override
    public void method_66473(class_2338 pos, class_2680 oldState) {
        if (method_10997() instanceof class_3218 serverWorld) {
            applyForceLoad(serverWorld, false);
        }
        super.method_66473(pos, oldState);
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        view.method_71465("RadiusIndex", radiusIndex);
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);
        radiusIndex = view.method_71424("RadiusIndex", 0);
    }
}

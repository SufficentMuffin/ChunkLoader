package com.example.chunkloader;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3218;

public final class ChunkLoaderCommands {
    private ChunkLoaderCommands() {
    }

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("chunkloader")
                .then(class_2170.method_9247("add")
                        .then(class_2170.method_9244("chunkX", IntegerArgumentType.integer())
                                .then(class_2170.method_9244("chunkZ", IntegerArgumentType.integer())
                                        .then(class_2170.method_9244("radius", IntegerArgumentType.integer())
                                                .executes(ChunkLoaderCommands::add)))))
                .then(class_2170.method_9247("remove")
                        .then(class_2170.method_9244("chunkX", IntegerArgumentType.integer())
                                .then(class_2170.method_9244("chunkZ", IntegerArgumentType.integer())
                                        .executes(ChunkLoaderCommands::remove)))));
    }

    private static int add(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_3218 world = source.method_9225();
        int chunkX = IntegerArgumentType.getInteger(ctx, "chunkX");
        int chunkZ = IntegerArgumentType.getInteger(ctx, "chunkZ");
        int radius = IntegerArgumentType.getInteger(ctx, "radius");
        return ChunkLoaderManager.add(world, chunkX, chunkZ, radius, source);
    }

    private static int remove(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_3218 world = source.method_9225();
        int chunkX = IntegerArgumentType.getInteger(ctx, "chunkX");
        int chunkZ = IntegerArgumentType.getInteger(ctx, "chunkZ");
        return ChunkLoaderManager.remove(world, chunkX, chunkZ, source);
    }
}
